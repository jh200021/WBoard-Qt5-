<?xml version="1.0" encoding="utf-8"?>
<!DOCTYPE TS>
<TS version="2.1" language="zh_CN">
<context>
    <name>PluginA</name>
    <message>
        <location filename="../UI/DemoLibraryA.ui" line="14"/>
        <source>Form</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <location filename="../UI/DemoLibraryA.ui" line="26"/>
        <source>打开图片</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <location filename="../UI/DemoLibraryA.ui" line="39"/>
        <source>调用B插件动画</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <location filename="../UI/DemoLibraryA.ui" line="52"/>
        <location filename="../UI/DemoLibraryA.ui" line="78"/>
        <source>TextLabel</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <location filename="../UI/DemoLibraryA.ui" line="65"/>
        <source>发向主程序</source>
        <translation type="unfinished"></translation>
    </message>
</context>
<context>
    <name>general_demo</name>
    <message>
        <location filename="../Include/Common/common_config.h" line="18"/>
        <source>关于我们</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <location filename="../Include/Common/common_config.h" line="19"/>
        <source>&lt;h2&gt;Demo 客户端 V1.0.0&lt;/h2&gt;&lt;p&gt;Copyright IMSBU&lt;/p&gt;&lt;p&gt;This client need an about description.&lt;/p&gt;</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <location filename="../Include/Common/common_config.h" line="20"/>
        <source>状态：</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <location filename="../Include/Common/common_config.h" line="21"/>
        <source>在线</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <location filename="../Include/Common/common_config.h" line="22"/>
        <source>暂时离开</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <location filename="../Include/Common/common_config.h" line="23"/>
        <source>忙碌</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <location filename="../Include/Common/common_config.h" line="24"/>
        <source>不在线</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <location filename="../Include/Common/common_config.h" line="25"/>
        <source>登录</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <location filename="../Include/Common/common_config.h" line="27"/>
        <source>&amp;文件</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <location filename="../Include/Common/common_config.h" line="28"/>
        <source>&amp;打开</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <location filename="../Include/Common/common_config.h" line="29"/>
        <source>&amp;保存</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <location filename="../Include/Common/common_config.h" line="30"/>
        <source>&amp;另存为</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <location filename="../Include/Common/common_config.h" line="31"/>
        <source>&amp;最近使用</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <location filename="../Include/Common/common_config.h" line="32"/>
        <source>&amp;保存截图</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <location filename="../Include/Common/common_config.h" line="33"/>
        <source>&amp;退出</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <location filename="../Include/Common/common_config.h" line="35"/>
        <source>&amp;视图</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <location filename="../Include/Common/common_config.h" line="36"/>
        <source>&amp;全屏</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <location filename="../Include/Common/common_config.h" line="38"/>
        <source>&amp;插件窗口</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <location filename="../Include/Common/common_config.h" line="40"/>
        <source>&amp;选择</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <location filename="../Include/Common/common_config.h" line="41"/>
        <source>&amp;主题</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <location filename="../Include/Common/common_config.h" line="42"/>
        <source>&amp;windows</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <location filename="../Include/Common/common_config.h" line="43"/>
        <source>&amp;darcula</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <location filename="../Include/Common/common_config.h" line="44"/>
        <source>&amp;语言</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <location filename="../Include/Common/common_config.h" line="45"/>
        <source>&amp;中文</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <location filename="../Include/Common/common_config.h" line="46"/>
        <source>&amp;英语</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <location filename="../Include/Common/common_config.h" line="48"/>
        <source>&amp;帮助</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <location filename="../Include/Common/common_config.h" line="49"/>
        <source>&amp;打开wiki</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <location filename="../Include/Common/common_config.h" line="50"/>
        <source>&amp;关于我们</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <location filename="../Include/Common/common_config.h" line="52"/>
        <location filename="../Include/Common/common_config.h" line="59"/>
        <source>设置</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <location filename="../Include/Common/common_config.h" line="53"/>
        <source>Master消息</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <location filename="../Include/Common/common_config.h" line="54"/>
        <source>任务呈现</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <location filename="../Include/Common/common_config.h" line="55"/>
        <source>视频</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <location filename="../Include/Common/common_config.h" line="57"/>
        <source>打开可视化</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <location filename="../Include/Common/common_config.h" line="58"/>
        <source>关闭可视化</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <location filename="../Include/Common/common_config.h" line="60"/>
        <source>任务</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <location filename="../Include/Common/common_config.h" line="61"/>
        <source>打开视频</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <location filename="../Include/Common/common_config.h" line="62"/>
        <source>关闭视频</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <location filename="../Include/Common/common_config.h" line="64"/>
        <source>保存图片</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <location filename="../Include/Common/common_config.h" line="65"/>
        <source>错误</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <location filename="../Include/Common/common_config.h" line="66"/>
        <source>将图像写入文件失败</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <location filename="../Include/Common/common_config.h" line="67"/>
        <source>支持的图像格式有：</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <location filename="../Include/Common/common_config.h" line="68"/>
        <source>保存整个demo窗口</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <location filename="../Include/Common/common_config.h" line="69"/>
        <source>图像将以原始分辨率保存。</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <location filename="../Include/Common/common_config.h" line="71"/>
        <source>插件窗口A</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <location filename="../Include/Common/common_config.h" line="72"/>
        <source>插件窗口B</source>
        <translation type="unfinished"></translation>
    </message>
</context>
<context>
    <name>settingPanelClass</name>
    <message>
        <location filename="../UI/setting.ui" line="35"/>
        <source>imageinfodlg</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <location filename="../UI/setting.ui" line="59"/>
        <source>xmpp设置</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <location filename="../UI/setting.ui" line="74"/>
        <location filename="../UI/setting.ui" line="150"/>
        <source>地址</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <location filename="../UI/setting.ui" line="91"/>
        <source>用户名</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <location filename="../UI/setting.ui" line="108"/>
        <source>密码</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <location filename="../UI/setting.ui" line="135"/>
        <source>任务设置</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <location filename="../UI/setting.ui" line="167"/>
        <source>端口</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <location filename="../UI/setting.ui" line="202"/>
        <source>保存</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <location filename="../UI/setting.ui" line="228"/>
        <source>重置</source>
        <translation type="unfinished"></translation>
    </message>
</context>
<context>
    <name>taskconfigurationdlgClass</name>
    <message>
        <location filename="../UI/task_configuration.ui" line="20"/>
        <source>imageinfodlg</source>
        <translation type="unfinished"></translation>
    </message>
</context>
</TS>
