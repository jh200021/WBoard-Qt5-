#ifndef WBWEBTOOLSPALLETTE_H_
#define WBWEBTOOLSPALLETTE_H_

#include "WBActionPalette.h"

class WBWebToolsPalette : public WBActionPalette
{
    Q_OBJECT

public:
    WBWebToolsPalette(QWidget *parent);
    virtual ~WBWebToolsPalette();

};

#endif /* WBWEBTOOLSPALLETTE_H_ */
